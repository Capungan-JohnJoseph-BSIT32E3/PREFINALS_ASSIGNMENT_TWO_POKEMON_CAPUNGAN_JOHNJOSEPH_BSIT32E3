using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace pokemon_prefinals.Views.Shared
{
    public class _PokemonListPartialModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
